from flask import Flask, render_template, request, session, redirect, url_for

import shelve, hashlib, os

app = Flask(__name__)
app.secret_key = os.urandom(24)

BASE_DIR = 'static/photos/'

PASS_LOCATION = 0
LIST_LOCATION = 1

ROSTER = shelve.open("users", writeback = True )


def authenticate( user, passw ):
	passw = hashlib.sha224(passw).hexdigest()
	return ROSTER[ user ][ PASS_LOCATION ] == passw

def validUser( user ):
	return user in ROSTER

def register( user, passw ):
	passwd = hashlib.sha224(passw).hexdigest()
	ROSTER[user] = [ passwd, [] ]
	if not os.path.exists(BASE_DIR + user):
		os.mkdir( BASE_DIR + user )

@app.route("/")
@app.route("/home")
def home():
	if 'user' in session:
		user = session['user']
		return render_template( "home.html", USER = user, PHOTOS = ROSTER[user][LIST_LOCATION] )
	else:
	    return render_template( "login.html" )

@app.route("/upload")
def upload():
	if 'user' in session:
		return render_template( "upload.html", USER = session['user'] )
	else:
		return render_template( "login.html" )

@app.route("/sendpic", methods=["POST"])
def sendpic():
	if 'user' in session:
		user = session['user']
		f = request.files['picture']
		saveName = BASE_DIR + user + '/' + f.filename
		if os.path.exists( BASE_DIR + user ):
			f.save( saveName )
			ROSTER[user][LIST_LOCATION].append( f.filename )			
		return redirect( url_for("home") )
	else:
	    return render_template( "login.html" )

@app.route("/logout")
def logout():
	if 'user' in session:
		session.pop('user')
		return redirect( url_for("home") )
	else:
	    return render_template( "login.html" )


@app.route("/login", methods=["POST"] )
def login():
	u = request.form['user']
	p = request.form['passw']

	if 'login' in request.form:
		if validUser(u):
			if authenticate( u, p ):
				session['user'] = u
				return redirect( url_for("home") )
			else:
				return render_template( "login.html", MESSAGE = "Incorrect Password" )	
		else:		
			return render_template( "login.html", MESSAGE = "Unregistered Username" )

	elif 'register' in request.form:

		if validUser(u):
			return render_template( "login.html", MESSAGE = "Username already taken")
		else:
			register( u, p )
			return render_template( "login.html", MESSAGE ="Registered user, please log in")



if __name__ == "__main__":
	app.debug = True
	app.run()
