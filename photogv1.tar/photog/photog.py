from flask import Flask, render_template, request

app = Flask(__name__)

USERNAME = "DarkHelmet"
PASSWORD = "12345"

def authenticate( user, passw ):
	return user == USERNAME and passw == PASSWORD

@app.route("/")
def home():
    return render_template( "login.html" )

@app.route("/login", methods=["POST"] )
def login():
	u = request.form['user']
	p = request.form['passw']
	if authenticate( u, p ):
		return "Success!"
	else:
		return "Failure"



if __name__ == "__main__":
	app.debug = True
	app.run()
