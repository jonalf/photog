from flask import Flask, render_template, request
import shelve

app = Flask(__name__)

ROSTER = { "DarkHelmet" : "12345", "t" : "butterscotch" }

USERNAME = "DarkHelmet"
PASSWORD = "12345"

"""
authenticate  without dictionaries

def authenticate( user, passw ):
	return user == USERNAME and passw == PASSWORD

def validUser( user ):
	return user == USERNAME
"""

def authenticate( user, passw ):
	return ROSTER[ user ] == passw

def validUser( user ):
	return user in ROSTER


@app.route("/")
def home():
    return render_template( "login.html" )

@app.route("/login", methods=["POST"] )
def login():
	u = request.form['user']
	p = request.form['passw']

	if 'login' in request.form:
		if validUser(u):
			if authenticate( u, p ):
				return 'Success'
			else:
				return render_template( "login.html", MESSAGE = "Incorrect Password" )	
		else:		
			return render_template( "login.html", MESSAGE = "Unregistered Username" )

	elif 'register' in request.form:

		if validUser(u):
			return render_template( "login.html", MESSAGE = "Username already taken")
		else:
			ROSTER[u] = p
			return render_template( "login.html", MESSAGE ="Registered user, please log in")



if __name__ == "__main__":
	app.debug = True
	app.run()
