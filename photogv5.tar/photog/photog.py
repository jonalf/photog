from flask import Flask, render_template, request, session, redirect, url_for

import shelve, hashlib, os

app = Flask(__name__)
app.secret_key = os.urandom(24)

BASE_DIR = 'photos/'

ROSTER = shelve.open("users")


def authenticate( user, passw ):
	passw = hashlib.sha224(passw).hexdigest()
	return ROSTER[ user ] == passw

def validUser( user ):
	return user in ROSTER

def register( user, passw ):
	passwd = hashlib.sha224(passw).hexdigest()
	ROSTER[user] = passwd

@app.route("/")
@app.route("/home")
def home():
	if 'user' in session:
		return render_template( "home.html", USER = session['user'] )
	else:
	    return render_template( "login.html" )

@app.route("/upload")
def upload():
	return render_template( "upload.html", USER = session['user'] )

@app.route("/sendpic", methods=["POST"])
def sendpic():

	f = request.files['picture']
	saveName = BASE_DIR + session['user'] + '/' + f.filename
	f.save( saveName )

	return redirect( url_for("home") )

@app.route("/logout")
def logout():
	session.pop('user')
	return redirect( url_for("home") )

@app.route("/login", methods=["POST"] )
def login():
	u = request.form['user']
	p = request.form['passw']

	if 'login' in request.form:
		if validUser(u):
			if authenticate( u, p ):
				session['user'] = u
				return render_template( "home.html", USER = u )
			else:
				return render_template( "login.html", MESSAGE = "Incorrect Password" )	
		else:		
			return render_template( "login.html", MESSAGE = "Unregistered Username" )

	elif 'register' in request.form:

		if validUser(u):
			return render_template( "login.html", MESSAGE = "Username already taken")
		else:
			register( u, p )
			return render_template( "login.html", MESSAGE ="Registered user, please log in")



if __name__ == "__main__":
	app.debug = True
	app.run()
